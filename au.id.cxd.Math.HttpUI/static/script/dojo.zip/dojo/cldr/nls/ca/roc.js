/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ca/roc",{"field-second":"segon","field-year-relative+-1":"Últim any","field-week":"setmana","field-month-relative+-1":"Últim mes","field-day-relative+-1":"ahir","field-day-relative+-2":"abans d'ahir","field-year":"any","field-week-relative+0":"Aquesta setmana","field-week-relative+1":"Setmana següent","field-minute":"minut","field-week-relative+-1":"Última setmana","field-day-relative+0":"avui","field-hour":"hora","field-day-relative+1":"demà","field-day-relative+2":"demà passat","field-day":"dia","field-month-relative+0":"Aquest mes","field-month-relative+1":"Mes següent","field-dayperiod":"a.m./p.m.","field-month":"mes","field-era":"era","field-year-relative+0":"Aquest any","field-year-relative+1":"Any següent","field-weekday":"dia de la setmana","field-zone":"zona"});
