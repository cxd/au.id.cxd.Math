define(
"dojo/cldr/nls/en-gb/currency", //begin v1.x content
{
	"CAD_symbol": "CA$",
	"EUR_displayName": "Euro",
	"GBP_displayName": "British Pound",
	"GBP_symbol": "£",
	"HKD_symbol": "HK$",
	"AUD_symbol": "AU$",
	"CNY_symbol": "CN¥",
	"EUR_symbol": "€"
}
//end v1.x content
);