define(
"dojo/cldr/nls/fr-ch/generic", //begin v1.x content
{
	"dateFormat-full": "EEEE, d MMMM y G",
	"dateFormat-short": "dd.MM.yy GGGGG"
}
//end v1.x content
);