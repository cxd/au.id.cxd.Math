/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/nb/currency",{"HKD_displayName":"Hongkong-dollar","CHF_displayName":"sveitsiske franc","CAD_displayName":"kanadiske dollar","CNY_displayName":"kinesiske yuan","AUD_displayName":"australske dollar","JPY_displayName":"japanske yen","USD_displayName":"amerikanske dollar","EUR_symbol":"€","GBP_displayName":"britiske pund sterling","GBP_symbol":"£","EUR_displayName":"euro"});
