/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ko/roc",{"field-second":"초","field-year-relative+-1":"지난해","field-week":"주","field-month-relative+-1":"지난달","field-day-relative+-1":"어제","field-day-relative+-2":"그저께","field-year":"년","field-week-relative+0":"이번 주","field-week-relative+1":"다음 주","field-minute":"분","field-week-relative+-1":"지난주","field-day-relative+0":"오늘","field-hour":"시","field-day-relative+1":"내일","field-day-relative+2":"모레","field-day":"일","field-month-relative+0":"이번 달","field-month-relative+1":"다음 달","field-dayperiod":"오전/오후","field-month":"월","field-era":"연호","field-year-relative+0":"올해","field-year-relative+1":"내년","eraAbbr":["중화민국전","중화민국"],"field-weekday":"요일","field-zone":"시간대"});
