define(
"dojo/cldr/nls/it/chinese", //begin v1.x content
{
	"dateFormat-medium": "dd/MMM U",
	"field-second": "secondo",
	"field-year-relative+-1": "Anno scorso",
	"field-week": "settimana",
	"field-month-relative+-1": "Mese scorso",
	"field-day-relative+-1": "ieri",
	"field-day-relative+-2": "l'altro ieri",
	"field-year": "anno",
	"field-week-relative+0": "Questa settimana",
	"field-week-relative+1": "Settimana prossima",
	"field-minute": "minuto",
	"field-week-relative+-1": "Settimana scorsa",
	"field-day-relative+0": "oggi",
	"field-hour": "ora",
	"field-day-relative+1": "domani",
	"dateFormat-long": "dd MMMM U",
	"field-day-relative+2": "dopodomani",
	"field-day": "giorno",
	"field-month-relative+0": "Questo mese",
	"field-month-relative+1": "Mese prossimo",
	"field-dayperiod": "periodo del giorno",
	"field-month": "mese",
	"dateFormat-short": "dd/MM/yy",
	"field-era": "era",
	"field-year-relative+0": "Questo anno",
	"field-year-relative+1": "Anno prossimo",
	"dateFormat-full": "EEEE d MMMM U",
	"field-weekday": "giorno della settimana",
	"field-zone": "zona"
}
//end v1.x content
);