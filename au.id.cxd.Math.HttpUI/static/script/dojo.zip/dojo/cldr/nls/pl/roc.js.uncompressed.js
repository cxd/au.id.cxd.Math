define(
"dojo/cldr/nls/pl/roc", //begin v1.x content
{
	"field-second": "Sekunda",
	"field-year-relative+-1": "Zeszły rok",
	"field-week": "Tydzień",
	"field-month-relative+-1": "Zeszły miesiąc",
	"field-day-relative+-1": "Wczoraj",
	"field-day-relative+-2": "Przedwczoraj",
	"field-year": "Rok",
	"field-week-relative+0": "Bieżący tydzień",
	"field-week-relative+1": "Przyszły tydzień",
	"field-minute": "Minuta",
	"field-week-relative+-1": "Zeszły tydzień",
	"field-day-relative+0": "Dzisiaj",
	"field-hour": "Godzina",
	"field-day-relative+1": "Jutro",
	"field-day-relative+2": "Pojutrze",
	"field-day": "Dzień",
	"field-month-relative+0": "Bieżący miesiąc",
	"field-month-relative+1": "Przyszły miesiąc",
	"field-dayperiod": "Dayperiod",
	"field-month": "Miesiąc",
	"field-era": "Era",
	"field-year-relative+0": "Bieżący rok",
	"field-year-relative+1": "Przyszły rok",
	"eraAbbr": [
		"Przed ROC",
		"ROC"
	],
	"field-weekday": "Dzień tygodnia",
	"field-zone": "Strefa"
}
//end v1.x content
);