define(
"dojo/cldr/nls/en/japanese", //begin v1.x content
{
	"dateFormat-medium": "MMM d, y G",
	"field-second": "Second",
	"field-year-relative+-1": "Last year",
	"field-week": "Week",
	"field-month-relative+-1": "Last month",
	"field-day-relative+-1": "Yesterday",
	"field-year": "Year",
	"field-week-relative+0": "This week",
	"field-week-relative+1": "Next week",
	"field-minute": "Minute",
	"field-week-relative+-1": "Last week",
	"field-day-relative+0": "Today",
	"field-hour": "Hour",
	"field-day-relative+1": "Tomorrow",
	"dateFormat-long": "MMMM d, y G",
	"field-day": "Day",
	"field-month-relative+0": "This month",
	"field-month-relative+1": "Next month",
	"field-dayperiod": "AM/PM",
	"field-month": "Month",
	"dateFormat-short": "M/d/y GGGGG",
	"field-era": "Era",
	"field-year-relative+0": "This year",
	"field-year-relative+1": "Next year",
	"dateFormat-full": "EEEE, MMMM d, y G",
	"field-weekday": "Day of the Week",
	"field-zone": "Time Zone"
}
//end v1.x content
);