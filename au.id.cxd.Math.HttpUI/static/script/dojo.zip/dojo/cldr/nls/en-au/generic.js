/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-au/generic",{"dateFormatItem-yMEd":"E, d/M/y","timeFormat-full":"h:mm:ss a zzzz","timeFormat-medium":"h:mm:ss a","dateFormatItem-MEd":"E, d/M","dateFormat-medium":"dd/MM/y G","dateFormatItem-yMd":"d/M/y","dateFormat-full":"EEEE, d MMMM y G","timeFormat-long":"h:mm:ss a z","timeFormat-short":"h:mm a","dateFormat-short":"d/MM/yy GGGGG","dateFormat-long":"d MMMM y G","dateFormatItem-MMMEd":"E, d MMM"});
