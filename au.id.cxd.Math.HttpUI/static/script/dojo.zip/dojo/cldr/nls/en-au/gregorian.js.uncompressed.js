define(
"dojo/cldr/nls/en-au/gregorian", //begin v1.x content
{
	"dateFormatItem-yMEd": "E, d/M/y",
	"timeFormat-full": "h:mm:ss a zzzz",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormatItem-MEd": "E, d/M",
	"dateFormat-medium": "dd/MM/y",
	"dateFormatItem-yMd": "d/M/y",
	"dateFormat-full": "EEEE, d MMMM y",
	"timeFormat-long": "h:mm:ss a z",
	"timeFormat-short": "h:mm a",
	"dateFormat-short": "d/MM/yy",
	"dateFormat-long": "d MMMM y",
	"dateFormatItem-MMMEd": "E, d MMM"
}
//end v1.x content
);