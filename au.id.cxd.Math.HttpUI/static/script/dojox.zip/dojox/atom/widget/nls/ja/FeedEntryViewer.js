//>>built
define("dojox/atom/widget/nls/ja/FeedEntryViewer",({displayOptions:"[表示オプション]",title:"タイトル",authors:"作成者",contributors:"貢献者",id:"ID",close:"[閉じる]",updated:"更新",summary:"要約",content:"内容"}));
