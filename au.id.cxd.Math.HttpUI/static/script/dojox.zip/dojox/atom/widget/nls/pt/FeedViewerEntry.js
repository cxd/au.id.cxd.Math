//>>built
define("dojox/atom/widget/nls/pt/FeedViewerEntry",({deleteButton:"[Excluir]"}));
