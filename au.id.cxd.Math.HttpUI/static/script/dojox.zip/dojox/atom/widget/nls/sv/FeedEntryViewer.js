//>>built
define("dojox/atom/widget/nls/sv/FeedEntryViewer",({displayOptions:"[visningsalternativ]",title:"Namn",authors:"Författare",contributors:"Medverkande",id:"ID",close:"[stäng]",updated:"Uppdaterat",summary:"Översikt",content:"Innehåll"}));
