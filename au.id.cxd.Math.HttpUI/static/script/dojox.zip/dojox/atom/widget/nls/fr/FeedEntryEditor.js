//>>built
define("dojox/atom/widget/nls/fr/FeedEntryEditor",({doNew:"[nouveau]",edit:"[éditer]",save:"[sauvegarder]",cancel:"[annuler]"}));
