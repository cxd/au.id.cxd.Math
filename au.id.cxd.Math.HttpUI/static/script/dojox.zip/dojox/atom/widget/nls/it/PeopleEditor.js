//>>built
define("dojox/atom/widget/nls/it/PeopleEditor",({add:"Aggiungi",addAuthor:"Aggiungi autore",addContributor:"Aggiungi contributor"}));
