//>>built
define("dojox/atom/widget/nls/hr/FeedEntryEditor",({doNew:"[novo]",edit:"[uredi]",save:"[spremi]",cancel:"[opoziv]"}));
