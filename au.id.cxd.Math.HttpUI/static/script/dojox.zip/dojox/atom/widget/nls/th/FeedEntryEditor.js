//>>built
define("dojox/atom/widget/nls/th/FeedEntryEditor",({doNew:"[สร้างใหม่]",edit:"[แก้ไข]",save:"[บันทึก]",cancel:"[ยกเลิก]"}));
