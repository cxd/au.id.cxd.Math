//>>built
define("dojox/atom/widget/nls/uk/FeedEntryViewer",({displayOptions:"[показати опції]",title:"Заголовок",authors:"Автори",contributors:"Учасники",id:"Ідентифікатор",close:"[закрити]",updated:"Оновлено",summary:"Підсумкові дані",content:"Вміст"}));
