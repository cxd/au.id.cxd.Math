//>>built
define("dojox/atom/widget/nls/sl/PeopleEditor",({add:"Dodaj",addAuthor:"Dodaj avtorja",addContributor:"Dodaj kontributorja"}));
