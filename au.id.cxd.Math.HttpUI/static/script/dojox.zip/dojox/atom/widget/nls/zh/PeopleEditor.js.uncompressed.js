define(
"dojox/atom/widget/nls/zh/PeopleEditor", ({
	add: "添加",
	addAuthor: "添加作者",
	addContributor: "添加添加者"
})
);
