//>>built
define("dojox/atom/widget/nls/ja/FeedViewerEntry",({deleteButton:"[削除]"}));
