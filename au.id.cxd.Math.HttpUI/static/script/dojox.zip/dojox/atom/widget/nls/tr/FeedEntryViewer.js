//>>built
define("dojox/atom/widget/nls/tr/FeedEntryViewer",({displayOptions:"[görüntüleme seçenekleri]",title:"Başlık",authors:"Yazarlar",contributors:"Katkıda Bulunanlar",id:"Kimlik",close:"[kapat]",updated:"Güncelleştirildi",summary:"Özet",content:"İçerik"}));
