//>>built
define("dojox/atom/widget/nls/tr/FeedViewerEntry",({deleteButton:"[Sil]"}));
