define(
"dojox/atom/widget/nls/pt-pt/FeedViewerEntry", ({
	deleteButton: "[Eliminar]"
})
);
