define(
"dojox/atom/widget/nls/sv/FeedViewerEntry", ({
	deleteButton: "[Ta bort]"
})
);
