//>>built
define("dojox/atom/widget/nls/bg/FeedEntryEditor",({doNew:"[нов]",edit:"[редактирай]",save:"[запази]",cancel:"[отмени]"}));
