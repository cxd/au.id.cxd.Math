//>>built
define("dojox/atom/widget/nls/hu/PeopleEditor",({add:"Hozzáadás",addAuthor:"Szerző hozzáadása",addContributor:"Közreműködő hozzáadása"}));
