//>>built
define("dojox/atom/widget/nls/nb/FeedEntryEditor",({doNew:"[ny(tt)]",edit:"[rediger]",save:"[lagre]",cancel:"[avbryt]"}));
