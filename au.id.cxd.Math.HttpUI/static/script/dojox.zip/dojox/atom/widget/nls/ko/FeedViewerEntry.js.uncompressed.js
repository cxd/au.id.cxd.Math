define(
"dojox/atom/widget/nls/ko/FeedViewerEntry", ({
	deleteButton: "[삭제]"
})
);
