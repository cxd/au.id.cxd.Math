define(
"dojox/atom/widget/nls/sl/FeedEntryViewer", ({
	displayOptions: "[možnosti prikaza]",
	title: "Naslov",
	authors: "Avtorji",
	contributors: "Kontributorji",
	id: "ID",
	close: "[zapri]",
	updated: "Posodobljeno",
	summary: "Seštevek",
	content: "Vsebina"
})
);
