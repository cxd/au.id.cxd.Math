define(
"dojox/atom/widget/nls/sk/FeedViewerEntry", ({
	deleteButton: "[Odstrániť]"
})
);
