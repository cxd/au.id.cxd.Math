define(
"dojox/atom/widget/nls/sk/FeedEntryEditor", ({
	doNew: "[nový]",
	edit: "[upraviť]",
	save: "[uložiť]",
	cancel: "[zrušiť]"
})
);
