//>>built
define("dojox/atom/widget/nls/ru/PeopleEditor",({add:"Добавить",addAuthor:"Добавить автора",addContributor:"Добавить участника"}));
