define(
"dojox/atom/widget/nls/bg/FeedViewerEntry", ({
	deleteButton: "[Изтрий]"
})
);
