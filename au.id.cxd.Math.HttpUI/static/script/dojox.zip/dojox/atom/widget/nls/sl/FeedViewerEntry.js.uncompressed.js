define(
"dojox/atom/widget/nls/sl/FeedViewerEntry", ({
	deleteButton: "[Izbriši]"
})
);
