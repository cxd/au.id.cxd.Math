define(
"dojox/atom/widget/nls/th/PeopleEditor", ({
	add: "เพิ่ม",
	addAuthor: "เพิ่มผู้เขียน",
	addContributor: "เพิ่มผู้ให้ข้อมูล"
})
);
