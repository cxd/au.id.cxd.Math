define(
"dojox/atom/widget/nls/ko/PeopleEditor", ({
	add: "추가",
	addAuthor: "작성자 추가",
	addContributor: "제공자 추가"
})
);
