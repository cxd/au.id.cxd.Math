//>>built
define("dojox/calendar/nls/sk/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Dnes",dayButton:"Deň",weekButton:"Týždeň",fourDaysButton:"4 dni",monthButton:"Mesiac"});
