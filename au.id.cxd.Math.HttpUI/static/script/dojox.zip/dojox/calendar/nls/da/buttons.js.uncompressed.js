define( "dojox/calendar/nls/da/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "I dag",
	dayButton: "Dag",
	weekButton: "Uge",
	fourDaysButton: "4 dage",
	monthButton: "Måned"
}
);
