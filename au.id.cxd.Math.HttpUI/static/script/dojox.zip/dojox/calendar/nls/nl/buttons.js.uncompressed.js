define( "dojox/calendar/nls/nl/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Vandaag",
	dayButton: "Dag",
	weekButton: "Week",
	fourDaysButton: "4 dagen",
	monthButton: "Maand"
}
);
