define( "dojox/calendar/nls/ko/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "오늘",
	dayButton: "일",
	weekButton: "주",
	fourDaysButton: "4일",
	monthButton: "월"
}
);
