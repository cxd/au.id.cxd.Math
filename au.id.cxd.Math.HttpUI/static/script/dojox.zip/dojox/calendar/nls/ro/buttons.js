//>>built
define("dojox/calendar/nls/ro/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Astăzi",dayButton:"Zi",weekButton:"Săptămână",fourDaysButton:"4 zile",monthButton:"Lună"});
