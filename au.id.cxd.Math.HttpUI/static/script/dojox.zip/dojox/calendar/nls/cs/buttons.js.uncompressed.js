define( "dojox/calendar/nls/cs/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Dnes",
	dayButton: "Den",
	weekButton: "Týden",
	fourDaysButton: "4 dny",
	monthButton: "Měsíc"
}
);
